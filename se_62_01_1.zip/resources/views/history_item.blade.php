@extends('template.layout')

@section('title','pinto')

@section('content')

<style>
    .set_Object_left {
        text-align: left;
    }

    .set_Object_Right {
        text-align: right;
    }

    .set_Object_Center {
        text-align: center;
    }
</style>

<div class="container">

    <div class="row mt-4">
        <div class="col-xl-12 col-12">
            <div class="card">
                <div class="card-header">
                    <div>
                        <strong style="float: left;">การค้นหา</strong>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-md-12 col-12">
                            <div class="row mb-4">
                                <div class="col-xl-3 col-12 text-right">
                                    <span>เลือก</span>
                                </div>
                                <div class="col-xl-9 col-12">
                                    <select name="fiter_status" id="fiter_status" class="js-example-basic-single from-control" style="width: 100%;">
                                        <option value="">Select</option>
                                        @foreach($item_data as $item)
                                        <option value="{{ $item->name }}">{{ $item->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-xl-3 col-12 text-right">
                                </div>
                                <div class="col-xl-9 col-12">
                                    <button type="button" name="filter" id="filter" class="btn btn-success" style="float: right; margin-left: 10px;">Filter</button>
                                    <button type="button" name="filter" id="reset" class="btn btn-secondary" style="float: right;">Reset</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="card-footer" style="text-align: right;">
                    <button type="button" name="filter" id="filter" class="btn btn-info" style="float: right; margin-left: 10px;">ประวัติอุปกรณ์</button>
                    <button type="button" name="filter" id="reset" class="btn btn-primary" style="float: right;">ประวัติรายการ</button>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-xl-12 col-12">
            <div class="card">
                <div class="card-header card-bg">
                    <div>
                        <strong style="float: left;">ประวัติ</strong>
                        <strong style="float: right;"></strong>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <?php
                        $th = ['id', 'listId', 'access_id', 'ชื่อ', 'status', 'วันที่ยืม', 'Action'];

                        createTable('tableFer', $th, $tb);
                        ?>
                        <br><br>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>


</div>
<script>
    $(document).ready(function() {
        $('#fiter_status').select2();
        $('#tableFer').DataTable({
            dom: '<"row"<"col-sm-6 set_Object_left"l><"col-sm-6"f>>' +
                '<"row"<"col-sm-12"tr>>' +
                '<"row"<"col-sm-5 set_Object_left"i><"col-sm-7"p>>'
        });
    });
</script>
@endsection
