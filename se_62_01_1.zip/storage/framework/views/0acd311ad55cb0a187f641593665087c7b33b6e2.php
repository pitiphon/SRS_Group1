
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/soa/style.css')); ?>">

</head>
<body>
    <div id="navbar">
        <?php echo $__env->make('soa.template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<div id="container" style="width: 70%; margin:auto">

    <div id="content" style="text-align: center">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</div>
</body>

</html>
<?php /**PATH F:\xampp\htdocs\se62\resources\views/soa/template/layout.blade.php ENDPATH**/ ?>