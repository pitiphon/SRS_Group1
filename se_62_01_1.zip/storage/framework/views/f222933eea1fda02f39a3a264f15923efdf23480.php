มีคำขอยืมจาก <?php echo e(session()->get("member")['thainame']); ?>

<?php /**PATH F:\xampp\htdocs\se62\resources\views/emails/mail.blade.php ENDPATH**/ ?>