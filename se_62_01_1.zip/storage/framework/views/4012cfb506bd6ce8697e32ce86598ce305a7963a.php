<?php $__env->startSection('title','pinto'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">


<div class="container">
    <div class="mt-5">

        <div class="">
            <h5 class="card-header mb-2">หมวดหมู่</h5>

            <div class="main">
                <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="accessoriesUser/<?php echo e($item->id); ?>">
                        <div class="card-body">
                            <img class="img-category" src="<?php echo e(asset($item->icon)); ?>" alt="">
                            <h6 class="card-title"><?php echo e($item->name); ?></h6>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

    </div>
</div>



<script>
//   let accessories = new Accessories()
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\se62\resources\views/indexUser.blade.php ENDPATH**/ ?>