

<?php $__env->startSection('title','pinto'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="mt-5">

    </div>

</div>
<script>
    // $('#tableFer').DataTable({
    //     // "scrollX": true
    // });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\se62\resources\views/index.blade.php ENDPATH**/ ?>