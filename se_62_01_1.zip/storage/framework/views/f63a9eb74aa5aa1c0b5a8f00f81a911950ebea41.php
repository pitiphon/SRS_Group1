<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/template/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/styles-template/sb-admin-2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/select2/style-select2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatables/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-googleapis/family_Material_Icon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-googleapis/family_Nunito.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cp-MDTimePicker/MDTimePicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fengyuanchen-Datepicker/datepicker.css')); ?>">

    <script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/styles-template/sb-admin-2.js')); ?>"></script>

    <script src="<?php echo e(asset('js/cp-MDTimePicker/MDTimePicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fengyuanchen-Datepicker/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fengyuanchen-Datepicker/datepicker.th-TH.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert/sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cp-MDTimePicker/MDTimePicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap4.min.js')); ?>"></script>

</head>

<body>
   
    <div id="navbar">
        <?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="container" style="width: 70%; margin:auto">

        <div id="header">
            <?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div id="content" style="text-align: center">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <div id="footer">
            <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</body>

</html><?php /**PATH F:\xampp\htdocs\se62\resources\views/template/layout.blade.php ENDPATH**/ ?>