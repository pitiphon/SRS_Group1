<?php $__env->startSection('title','pinto'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('soa.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\se62\resources\views/soa/index.blade.php ENDPATH**/ ?>