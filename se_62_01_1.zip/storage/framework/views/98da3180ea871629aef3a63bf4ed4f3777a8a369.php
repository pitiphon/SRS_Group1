<nav class="navbar navbar-light nav-top">
    <a class="navbar-brand" href="#">Navbar</a>
  </nav>
  <nav class="navbar navbar-light nav-main">
    <a class="navbar-brand" href="#">Navbar</a>
  </nav>
<?php /**PATH F:\xampp\htdocs\se62\resources\views/soa/template/navbar.blade.php ENDPATH**/ ?>