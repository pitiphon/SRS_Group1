<?php $__env->startSection('title','pinto'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/login/style.css')); ?>">
<div class="container">
    <div class="login-form">
        <div class="logo">
            <img src="<?php echo e(asset('img/KU_SubLogo.png')); ?>" alt=""><strong>ระบบยืมคืนอุปกรณ์</strong>
        </div>
        <form  method="post" action="/login">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
                <input type="text" class="form-control" name="username" placeholder="username">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="password">
            </div>
            <button class="btn btn-success" type="submit">Login</button>

        </form>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\se62\resources\views/login.blade.php ENDPATH**/ ?>