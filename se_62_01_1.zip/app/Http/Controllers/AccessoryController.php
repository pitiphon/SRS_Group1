<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Catagories;
class AccessoryController extends Controller
{
    function index(){

    }
}
