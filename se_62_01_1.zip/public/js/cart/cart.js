class Cart{
    id
    access_key
    name
    description
    icon
    number = 0
    constructor(id,access_key,name , description,icon,number){
        this.id = id;
        this.access_key = access_key;
        this.name = name;
        this.description = description;
        this.icon = icon;
        this.number = number;
    }
}
